
  # Construir Landing Page MVP

  This is a code bundle for Construir Landing Page MVP. The original project is available at https://www.figma.com/design/mRH4k41O6b9MRlSjW9OTW7/Construir-Landing-Page-MVP.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
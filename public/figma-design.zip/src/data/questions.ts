import { Question } from '../types/quiz';

export const questions: Question[] = [
  {
    id: 1,
    text: "Quando você tem tempo livre, você prefere:",
    options: [
      {
        text: "Ler, escrever ou estudar algo novo",
        categories: { humanas: 3, exatas: 1, biologicas: 1 }
      },
      {
        text: "Resolver quebra-cabeças, jogos de lógica ou programar",
        categories: { exatas: 3, humanas: 1, biologicas: 1 }
      },
      {
        text: "Cuidar de plantas, animais ou fazer atividades ao ar livre",
        categories: { biologicas: 3, humanas: 1, exatas: 1 }
      },
      {
        text: "Conversar com amigos e participar de atividades em grupo",
        categories: { humanas: 2, biologicas: 2, exatas: 1 }
      }
    ]
  },
  {
    id: 2,
    text: "Qual tipo de problema você mais gosta de resolver?",
    options: [
      {
        text: "Questões sociais e comportamentais",
        categories: { humanas: 3, biologicas: 1, exatas: 0 }
      },
      {
        text: "Cálculos matemáticos e desafios tecnológicos",
        categories: { exatas: 3, humanas: 0, biologicas: 1 }
      },
      {
        text: "Relacionados à saúde e bem-estar",
        categories: { biologicas: 3, humanas: 1, exatas: 0 }
      },
      {
        text: "Organização e planejamento estratégico",
        categories: { exatas: 2, humanas: 2, biologicas: 0 }
      }
    ]
  },
  {
    id: 3,
    text: "Em um projeto em grupo, você prefere:",
    options: [
      {
        text: "Liderar e organizar as pessoas",
        categories: { humanas: 3, exatas: 1, biologicas: 1 }
      },
      {
        text: "Fazer a parte técnica e análise de dados",
        categories: { exatas: 3, humanas: 0, biologicas: 1 }
      },
      {
        text: "Pesquisar e apresentar informações científicas",
        categories: { biologicas: 3, exatas: 1, humanas: 1 }
      },
      {
        text: "Criar apresentações e comunicar ideias",
        categories: { humanas: 3, exatas: 0, biologicas: 0 }
      }
    ]
  },
  {
    id: 4,
    text: "Qual matéria escolar você mais gosta?",
    options: [
      {
        text: "História, Geografia, Filosofia ou Línguas",
        categories: { humanas: 3, biologicas: 0, exatas: 0 }
      },
      {
        text: "Matemática, Física ou Química",
        categories: { exatas: 3, humanas: 0, biologicas: 1 }
      },
      {
        text: "Biologia e Ciências da Natureza",
        categories: { biologicas: 3, humanas: 0, exatas: 1 }
      },
      {
        text: "Educação Física e Artes",
        categories: { humanas: 2, biologicas: 2, exatas: 0 }
      }
    ]
  },
  {
    id: 5,
    text: "O que mais te motiva em uma carreira?",
    options: [
      {
        text: "Ajudar pessoas e fazer diferença na sociedade",
        categories: { humanas: 3, biologicas: 2, exatas: 0 }
      },
      {
        text: "Inovar e criar soluções tecnológicas",
        categories: { exatas: 3, humanas: 1, biologicas: 0 }
      },
      {
        text: "Descobrir coisas novas sobre a vida e saúde",
        categories: { biologicas: 3, exatas: 1, humanas: 1 }
      },
      {
        text: "Estabilidade financeira e reconhecimento",
        categories: { exatas: 2, humanas: 2, biologicas: 1 }
      }
    ]
  },
  {
    id: 6,
    text: "Como você prefere aprender?",
    options: [
      {
        text: "Lendo textos, debatendo ideias e escrevendo",
        categories: { humanas: 3, biologicas: 0, exatas: 0 }
      },
      {
        text: "Praticando exercícios e resolvendo problemas",
        categories: { exatas: 3, humanas: 0, biologicas: 1 }
      },
      {
        text: "Fazendo experimentos e observando",
        categories: { biologicas: 3, exatas: 1, humanas: 0 }
      },
      {
        text: "Assistindo vídeos e participando de discussões",
        categories: { humanas: 2, biologicas: 1, exatas: 1 }
      }
    ]
  },
  {
    id: 7,
    text: "Qual ambiente de trabalho você prefere?",
    options: [
      {
        text: "Escritório com pessoas, reuniões e networking",
        categories: { humanas: 3, exatas: 1, biologicas: 0 }
      },
      {
        text: "Ambiente tecnológico ou laboratório",
        categories: { exatas: 3, biologicas: 2, humanas: 0 }
      },
      {
        text: "Hospital, clínica ou campo de pesquisa",
        categories: { biologicas: 3, humanas: 1, exatas: 0 }
      },
      {
        text: "Flexível, podendo trabalhar remotamente",
        categories: { exatas: 2, humanas: 2, biologicas: 1 }
      }
    ]
  },
  {
    id: 8,
    text: "Qual seu maior talento natural?",
    options: [
      {
        text: "Comunicação e relacionamento interpessoal",
        categories: { humanas: 3, biologicas: 1, exatas: 0 }
      },
      {
        text: "Raciocínio lógico e análise",
        categories: { exatas: 3, humanas: 0, biologicas: 1 }
      },
      {
        text: "Cuidado e empatia com outros",
        categories: { biologicas: 3, humanas: 2, exatas: 0 }
      },
      {
        text: "Criatividade e inovação",
        categories: { humanas: 2, exatas: 2, biologicas: 1 }
      }
    ]
  },
  {
    id: 9,
    text: "O que você faria em um fim de semana ideal?",
    options: [
      {
        text: "Visitar museus, exposições ou eventos culturais",
        categories: { humanas: 3, biologicas: 0, exatas: 0 }
      },
      {
        text: "Participar de hackathons ou aprender novas tecnologias",
        categories: { exatas: 3, humanas: 0, biologicas: 0 }
      },
      {
        text: "Fazer trilhas, acampar ou atividades na natureza",
        categories: { biologicas: 3, humanas: 1, exatas: 0 }
      },
      {
        text: "Sair com amigos ou fazer trabalho voluntário",
        categories: { humanas: 3, biologicas: 2, exatas: 0 }
      }
    ]
  },
  {
    id: 10,
    text: "Qual tipo de livro ou conteúdo você prefere?",
    options: [
      {
        text: "Romance, biografia, política ou psicologia",
        categories: { humanas: 3, biologicas: 1, exatas: 0 }
      },
      {
        text: "Ficção científica, tecnologia ou matemática",
        categories: { exatas: 3, humanas: 0, biologicas: 1 }
      },
      {
        text: "Saúde, natureza, medicina ou biologia",
        categories: { biologicas: 3, humanas: 0, exatas: 1 }
      },
      {
        text: "Autoajuda, negócios e desenvolvimento pessoal",
        categories: { humanas: 2, exatas: 2, biologicas: 1 }
      }
    ]
  }
];

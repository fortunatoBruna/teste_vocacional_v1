import { CareerProfile } from '../types/quiz';

export const careerProfiles: Record<string, CareerProfile> = {
  humanas: {
    id: 'humanas',
    title: 'Perfil de Humanas',
    description: 'Você tem forte afinidade com ciências humanas e sociais! Seu perfil é ideal para áreas que envolvem comunicação, liderança, relações humanas e impacto social.',
    characteristics: [
      'Excelente comunicação e habilidades interpessoais',
      'Interesse genuíno em questões sociais, culturais e comportamentais',
      'Capacidade natural de liderança e trabalho em equipe',
      'Gosta de ler, escrever, debater e expressar ideias',
      'Empatia e facilidade para entender o comportamento humano'
    ],
    careers: [
      'Direito',
      'Psicologia',
      'Administração',
      'Recursos Humanos',
      'Pedagogia',
      'Serviço Social',
      'Marketing Digital',
      'Gestão Comercial',
      'Gestão de RH',
      'Processos Gerenciais',
      'Gestão Pública',
      'História'
    ],
    color: 'bg-[#1880c4]'
  },
  exatas: {
    id: 'exatas',
    title: 'Perfil de Exatas',
    description: 'Você se destaca em ciências exatas e tecnologia! Seu perfil é perfeito para áreas que exigem raciocínio lógico, análise de dados e soluções inovadoras.',
    characteristics: [
      'Raciocínio lógico-matemático muito desenvolvido',
      'Fascínio por tecnologia, inovação e sistemas',
      'Excelente capacidade de resolver problemas complexos',
      'Atenção excepcional aos detalhes e precisão',
      'Habilidade para analisar dados e criar soluções práticas'
    ],
    careers: [
      'Engenharia da Computação',
      'Análise e Desenvolvimento de Sistemas',
      'Ciência de Dados',
      'Engenharia de Produção',
      'Gestão da Tecnologia da Informação',
      'Sistemas de Informação',
      'Matemática',
      'Estatística',
      'Logística',
      'Gestão Financeira',
      'Economia',
      'Contabilidade'
    ],
    color: 'bg-[#009444]'
  },
  biologicas: {
    id: 'biologicas',
    title: 'Perfil de Biológicas',
    description: 'Você tem vocação para ciências biológicas e da saúde! Seu perfil combina perfeitamente com áreas dedicadas ao cuidado, bem-estar e qualidade de vida.',
    characteristics: [
      'Interesse profundo por saúde, bem-estar e qualidade de vida',
      'Grande empatia e desejo genuíno de ajudar pessoas',
      'Curiosidade científica sobre a vida e o corpo humano',
      'Capacidade aguçada de observação e análise clínica',
      'Paciência e dedicação ao cuidado com seres vivos'
    ],
    careers: [
      'Enfermagem',
      'Nutrição',
      'Fisioterapia',
      'Educação Física',
      'Estética e Cosmética',
      'Biomedicina',
      'Farmácia',
      'Gestão Hospitalar',
      'Radiologia',
      'Saúde Coletiva',
      'Gerontologia',
      'Psicologia (área clínica)'
    ],
    color: 'bg-[#fab71b]'
  }
};

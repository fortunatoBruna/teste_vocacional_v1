import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { QuizQuestion } from './components/QuizQuestion';
import { ResultsPage } from './components/ResultsPage';
import { questions } from './data/questions';
import { careerProfiles } from './data/profiles';
import { QuizResult } from './types/quiz';

type AppState = 'landing' | 'quiz' | 'results';

export default function App() {
  const [appState, setAppState] = useState<AppState>('landing');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);

  const handleStartQuiz = () => {
    setAppState('quiz');
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setSelectedOption(null);
    setQuizResult(null);
  };

  const handleSelectOption = (optionIndex: number) => {
    setSelectedOption(optionIndex);
  };

  const handleNext = () => {
    if (selectedOption === null) return;

    // Save answer
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = selectedOption;
    setAnswers(newAnswers);

    // Check if it's the last question
    if (currentQuestionIndex === questions.length - 1) {
      // Calculate results
      calculateResults(newAnswers);
    } else {
      // Move to next question
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      // Load saved answer for next question if it exists
      setSelectedOption(newAnswers[currentQuestionIndex + 1] ?? null);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      setSelectedOption(answers[currentQuestionIndex - 1] ?? null);
    }
  };

  const calculateResults = (finalAnswers: number[]) => {
    const scores = {
      humanas: 0,
      exatas: 0,
      biologicas: 0,
    };

    // Calculate scores based on answers
    finalAnswers.forEach((answerIndex, questionIndex) => {
      const question = questions[questionIndex];
      const selectedAnswer = question.options[answerIndex];
      
      Object.entries(selectedAnswer.categories).forEach(([category, points]) => {
        scores[category as keyof typeof scores] += points;
      });
    });

    // Find the dominant profile
    const dominantProfile = Object.entries(scores).reduce((max, current) =>
      current[1] > max[1] ? current : max
    )[0];

    const result: QuizResult = {
      profile: careerProfiles[dominantProfile],
      scores: scores,
    };

    setQuizResult(result);
    setAppState('results');
  };

  const handleRestart = () => {
    setAppState('landing');
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setSelectedOption(null);
    setQuizResult(null);
  };

  if (appState === 'landing') {
    return <LandingPage onStart={handleStartQuiz} />;
  }

  if (appState === 'quiz') {
    return (
      <QuizQuestion
        question={questions[currentQuestionIndex]}
        currentQuestion={currentQuestionIndex}
        totalQuestions={questions.length}
        selectedOption={selectedOption}
        onSelectOption={handleSelectOption}
        onNext={handleNext}
        onPrevious={handlePrevious}
      />
    );
  }

  if (appState === 'results' && quizResult) {
    return <ResultsPage result={quizResult} onRestart={handleRestart} />;
  }

  return null;
}

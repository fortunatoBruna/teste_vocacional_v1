import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { QuizResult } from "../types/quiz";
import { Progress } from "./ui/progress";

interface ResultsPageProps {
  result: QuizResult;
  onRestart: () => void;
}

export function ResultsPage({ result, onRestart }: ResultsPageProps) {
  const { profile, scores } = result;

  // Calculate percentages
  const totalScore = Object.values(scores).reduce((sum, score) => sum + score, 0);
  const percentages = Object.entries(scores).reduce((acc, [key, value]) => {
    acc[key] = Math.round((value / totalScore) * 100);
    return acc;
  }, {} as Record<string, number>);

  const handleShare = () => {
    const shareText = `Descobri meu perfil vocacional: ${profile.title}! Faça você também o Teste Vocacional da UFBRA e descubra qual curso é ideal para você! 🎓`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Meu Resultado - Teste Vocacional UFBRA',
        text: shareText,
      }).catch(() => {
        copyToClipboard(shareText);
      });
    } else {
      copyToClipboard(shareText);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Texto copiado! Cole onde quiser compartilhar. 📋');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="container mx-auto max-w-4xl">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-[#009444] rounded-full shadow-lg mb-4">
            <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h1 className="mb-2 text-[#1880c4]">Parabéns! Seu Resultado está Pronto!</h1>
          <p className="text-gray-700 leading-relaxed">
            Descubra agora qual área combina mais com você e os cursos ideais da UFBRA
          </p>
        </div>

        {/* Main Profile Card */}
        <Card className={`p-8 md:p-12 shadow-2xl mb-6 ${profile.color} text-white`}>
          <div className="text-center">
            <div className="mb-4">
              <svg className="w-16 h-16 mx-auto text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
            </div>
            <h2 className="text-center mb-4 text-white">{profile.title}</h2>
            <p className="text-center text-lg mb-2 text-white/95 leading-relaxed">
              {profile.description}
            </p>
          </div>
        </Card>

        {/* Score Breakdown */}
        <Card className="p-8 mb-6 shadow-xl bg-white border-2 border-[#1880c4]/10">
          <div className="flex items-center gap-2 mb-6">
            <svg className="w-6 h-6 text-[#1880c4]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            <h3 className="text-[#1880c4]">Sua Pontuação por Área</h3>
          </div>
          
          <div className="space-y-5">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-800">Humanas</span>
                <span className="text-[#1880c4]">{percentages.humanas}%</span>
              </div>
              <Progress value={percentages.humanas} className="h-3 [&>div]:bg-[#1880c4]" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-800">Exatas</span>
                <span className="text-[#009444]">{percentages.exatas}%</span>
              </div>
              <Progress value={percentages.exatas} className="h-3 [&>div]:bg-[#009444]" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-800">Biológicas</span>
                <span className="text-[#fab71b]">{percentages.biologicas}%</span>
              </div>
              <Progress value={percentages.biologicas} className="h-3 [&>div]:bg-[#fab71b]" />
            </div>
          </div>
        </Card>

        {/* Characteristics */}
        <Card className="p-8 mb-6 shadow-xl bg-white border-2 border-[#009444]/10">
          <div className="flex items-center gap-2 mb-6">
            <svg className="w-6 h-6 text-[#009444]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="text-[#009444]">Características do Seu Perfil</h3>
          </div>
          
          <ul className="space-y-3">
            {profile.characteristics.map((characteristic, index) => (
              <li key={index} className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 bg-[#009444] rounded-full flex items-center justify-center mt-0.5">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-gray-800 leading-relaxed">{characteristic}</span>
              </li>
            ))}
          </ul>
        </Card>

        {/* Career Suggestions */}
        <Card className="p-8 mb-6 shadow-xl bg-white border-2 border-[#fab71b]/10">
          <div className="flex items-center gap-2 mb-6">
            <svg className="w-6 h-6 text-[#fab71b]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
            <h3 className="text-[#fab71b]">Cursos EaD Recomendados na UFBRA</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {profile.careers.map((career, index) => (
              <div
                key={index}
                className="p-4 bg-gradient-to-br from-gray-50 to-white rounded-lg text-center border-2 border-gray-100 hover:border-[#fab71b] transition-all hover:shadow-md"
              >
                <span className="text-gray-800">{career}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Next Steps */}
        <Card className="p-8 mb-6 shadow-xl ufbra-gradient-blue">
          <h3 className="mb-6 text-white text-center">Próximos Passos para Sua Carreira</h3>
          <ul className="space-y-4 text-white">
            <li className="flex items-start gap-4">
              <span className="flex-shrink-0 w-10 h-10 bg-white text-[#1880c4] rounded-full flex items-center justify-center">
                1
              </span>
              <span className="leading-relaxed">
                <strong>Explore os cursos EaD da UFBRA:</strong> Veja detalhes sobre grade curricular, duração, valores e formas de ingresso. Tudo 100% online!
              </span>
            </li>
            <li className="flex items-start gap-4">
              <span className="flex-shrink-0 w-10 h-10 bg-white text-[#1880c4] rounded-full flex items-center justify-center">
                2
              </span>
              <span className="leading-relaxed">
                <strong>Converse com profissionais da área:</strong> Busque entender o dia a dia e as oportunidades do mercado de trabalho
              </span>
            </li>
            <li className="flex items-start gap-4">
              <span className="flex-shrink-0 w-10 h-10 bg-white text-[#1880c4] rounded-full flex items-center justify-center">
                3
              </span>
              <span className="leading-relaxed">
                <strong>Faça sua matrícula na UFBRA:</strong> Entrada facilitada, mensalidades acessíveis e estudo flexível que se adapta à sua rotina!
              </span>
            </li>
          </ul>
        </Card>

        {/* CTA Banner */}
        <Card className="p-8 mb-6 shadow-xl ufbra-gradient-tricolor text-center">
          <h3 className="text-white mb-4">Pronto para Dar o Próximo Passo?</h3>
          <p className="text-white/95 mb-6 leading-relaxed max-w-2xl mx-auto">
            A UFBRA oferece cursos EaD de qualidade, com mensalidades que cabem no seu bolso e horários flexíveis para você conciliar trabalho, família e estudos!
          </p>
          <Button
            size="lg"
            className="bg-white hover:bg-gray-100 text-[#1880c4] shadow-xl"
          >
            Conhecer Cursos da UFBRA
          </Button>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
          <Button
            onClick={handleShare}
            variant="outline"
            size="lg"
            className="gap-2 border-2 border-[#1880c4] text-[#1880c4] hover:bg-[#1880c4] hover:text-white"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
            </svg>
            Compartilhar Resultado
          </Button>
          <Button
            onClick={onRestart}
            size="lg"
            className="gap-2 bg-[#fab71b] hover:bg-[#e5a610] text-black"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Refazer o Teste
          </Button>
        </div>

        {/* Disclaimer */}
        <p className="text-center text-sm text-gray-600 max-w-2xl mx-auto leading-relaxed">
          <strong>UFBRA - Universidade Federal do Brasil</strong><br />
          Este resultado é uma orientação baseada em suas respostas. 
          Para uma análise mais completa e personalizada sobre sua vocação, consulte também um profissional de orientação vocacional.
        </p>
      </div>
    </div>
  );
}

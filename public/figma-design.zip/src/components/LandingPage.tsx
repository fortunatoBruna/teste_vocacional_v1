import { Button } from "./ui/button";
import { Card } from "./ui/card";
import logoUfbra from "figma:asset/886b536de3f282d731e5fbf9e0d2ec4a2ada9cf7.png";

interface LandingPageProps {
  onStart: () => void;
}

export function LandingPage({ onStart }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center">
              <img src={logoUfbra} alt="UFBRA" className="h-8 md:h-10" />
            </div>

            {/* Título */}
            <h1 className="text-xl md:text-2xl font-normal text-gray-800 text-center">
              Teste Vocacional
            </h1>


            
            {/* Badge com ponto piscante */}
            <div className="flex items-center gap-2 bg-[#009444]/10 px-4 py-2 rounded-full border border-[#009444]/20">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#009444] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-[#009444]"></span>
              </span>
              <span className="text-sm text-[#009444]">Online e gratuito</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="container mx-auto px-4 py-12 md:py-20 mt-20">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          <div className="mb-8 p-6 bg-[#1880c4] rounded-full shadow-lg">
            <svg className="w-16 h-16 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" />
            </svg>
          </div>
          
          <h1 className="mb-6 text-4xl md:text-5xl lg:text-6xl text-[#1880c4] text-[64px] font-normal">
            Descubra seu curso ideal em <strong>3 minutos</strong>
          </h1>
          
          <p className="mb-8 text-gray-700 max-w-2xl text-lg leading-relaxed">
            Responda 32 perguntas rápidas baseadas em suas habilidades e preferências e receba seu ranking personalizado de cursos universitários.
          </p>

          <Button 
            onClick={onStart} 
            size="lg"
            className="bg-[#fab71b] hover:bg-[#e5a610] text-black px-8 py-6 text-lg shadow-xl hover:shadow-2xl transition-all"
          >
            Começar agora
          </Button>

          <p className="mt-4 text-sm text-gray-600">
            ✓ Resultado imediato
          </p>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <Card className="p-6 text-center hover:shadow-lg transition-shadow bg-white border-2 border-[#1880c4]/10">
              <div className="flex justify-center mb-4">
                <div className="p-4 bg-[#1880c4] rounded-full">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <h3 className="mb-2 text-[#1880c4]">Resultado Personalizado</h3>
              <p className="text-gray-700 leading-relaxed">
                Análise detalhada do seu perfil com sugestões de carreiras específicas e cursos da UFBRA
              </p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow bg-white border-2 border-[#009444]/10">
              <div className="flex justify-center mb-4">
                <div className="p-4 bg-[#009444] rounded-full">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
              </div>
              <h3 className="mb-2 text-[#009444]">Baseado em Ciência</h3>
              <p className="text-gray-700 leading-relaxed">
                Desenvolvido com base na Teoria das Inteligências Múltiplas de Howard Gardner
              </p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow bg-white border-2 border-[#fab71b]/10">
              <div className="flex justify-center mb-4">
                <div className="p-4 bg-[#fab71b] rounded-full">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <h3 className="mb-2 text-[#fab71b]">100% Gratuito</h3>
              <p className="text-gray-700 leading-relaxed">
                Sem custos, sem cadastro obrigatório. Resultado na hora!
              </p>
            </Card>
          </div>
        </div>
      </div>

      {/* How it Works */}
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-8 md:p-12 border-2 border-[#1880c4]/10">
          <h2 className="text-center mb-8 text-[#1880c4]">Como Funciona o Teste?</h2>
          
          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-[#1880c4] rounded-full flex items-center justify-center text-white text-xl">
                1
              </div>
              <div>
                <h4 className="text-[#1880c4]">Responda perguntas rápidas</h4>
                <p className="text-gray-700 leading-relaxed">
                  Perguntas simples sobre suas preferências, habilidades e o que te motiva
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-[#1880c4] rounded-full flex items-center justify-center text-white text-xl">
                2
              </div>
              <div>
                <h4 className="text-[#1880c4]">Análise do seu perfil</h4>
                <p className="text-gray-700 leading-relaxed">
                  Nosso sistema analisa suas respostas e identifica qual área tem mais a ver com você
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-[#1880c4] rounded-full flex items-center justify-center text-white text-xl">
                3
              </div>
              <div>
                <h4 className="text-[#1880c4]">Receba seu resultado completo</h4>
                <p className="text-gray-700 leading-relaxed">
                  Veja seu perfil detalhado, carreiras ideais e os cursos de graduação da UFBRA perfeitos pra você
                </p>
              </div>
            </div>
          </div>


        </div>
      </div>

      {/* CTA Section */}
      <div className="ufbra-gradient-tricolor py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-white mb-4">
            <strong>Pronto para descobrir seu curso ideal?</strong>
          </h2>
          <p className="text-white/90 mb-8 text-lg max-w-2xl mx-auto leading-relaxed">
            Milhares de estudantes já descobriram. Comece agora e dê o primeiro passo para uma carreira de sucesso!
          </p>
          <Button 
            onClick={onStart}
            size="lg"
            className="bg-white hover:bg-gray-100 text-[#1880c4] px-8 py-6 shadow-xl"
          >
            Fazer teste vocacional grátis
          </Button>
        </div>
      </div>

      {/* Footer */}
      <div className="container mx-auto px-4 py-8">
        <p className="text-center text-gray-600 text-sm leading-relaxed max-w-3xl mx-auto">
          <strong>UFBRA • R. Dolzani Ricardo, 335 • São José dos Campos • SP</strong><br />
          Este teste é uma ferramenta de orientação inicial gratuita. 
          Para decisões definitivas sobre sua carreira, consulte também um orientador vocacional profissional.
        </p>
      </div>
    </div>
  );
}
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Question } from "../types/quiz";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Label } from "./ui/label";
import { Progress } from "./ui/progress";

interface QuizQuestionProps {
  question: Question;
  currentQuestion: number;
  totalQuestions: number;
  selectedOption: number | null;
  onSelectOption: (optionIndex: number) => void;
  onNext: () => void;
  onPrevious: () => void;
}

export function QuizQuestion({
  question,
  currentQuestion,
  totalQuestions,
  selectedOption,
  onSelectOption,
  onNext,
  onPrevious,
}: QuizQuestionProps) {
  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="container mx-auto max-w-3xl">
        {/* Header com Logo */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 mb-2">
            <div className="w-10 h-10 bg-[#1880c4] rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" />
              </svg>
            </div>
            <span className="text-[#1880c4]">Teste Vocacional UFBRA</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-700">
              Questão {currentQuestion + 1} de {totalQuestions}
            </span>
            <span className="text-sm text-[#1880c4]">
              {Math.round(progress)}%
            </span>
          </div>
          <Progress value={progress} className="h-3 bg-gray-200" />
        </div>

        {/* Question Card */}
        <Card className="p-8 md:p-12 shadow-xl bg-white border-2 border-[#1880c4]/10">
          <h2 className="mb-8 text-center text-[#1880c4]">{question.text}</h2>

          <RadioGroup
            value={selectedOption !== null ? selectedOption.toString() : undefined}
            onValueChange={(value) => onSelectOption(parseInt(value))}
          >
            <div className="space-y-4">
              {question.options.map((option, index) => (
                <div
                  key={index}
                  className={`flex items-start space-x-3 p-5 rounded-lg border-2 transition-all cursor-pointer hover:bg-gray-50 ${
                    selectedOption === index
                      ? "border-[#fab71b] bg-[#fab71b]/5 shadow-md"
                      : "border-gray-200"
                  }`}
                  onClick={() => onSelectOption(index)}
                >
                  <RadioGroupItem
                    value={index.toString()}
                    id={`option-${index}`}
                    className="mt-1"
                  />
                  <Label
                    htmlFor={`option-${index}`}
                    className="flex-1 cursor-pointer text-gray-800 leading-relaxed"
                  >
                    {option.text}
                  </Label>
                </div>
              ))}
            </div>
          </RadioGroup>

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8 gap-4">
            <Button
              onClick={onPrevious}
              variant="outline"
              disabled={currentQuestion === 0}
              className="w-32 border-2 border-[#1880c4] text-[#1880c4] hover:bg-[#1880c4] hover:text-white disabled:opacity-50"
            >
              Voltar
            </Button>
            <Button
              onClick={onNext}
              disabled={selectedOption === null}
              className="w-32 bg-[#fab71b] hover:bg-[#e5a610] text-black disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {currentQuestion === totalQuestions - 1 ? "Finalizar" : "Próxima"}
            </Button>
          </div>
        </Card>

        {/* Help Text */}
        <p className="text-center mt-6 text-sm text-gray-600">
          💡 Escolha a opção que mais combina com você. Não existe resposta certa ou errada!
        </p>
      </div>
    </div>
  );
}

export interface Question {
  id: number;
  text: string;
  options: {
    text: string;
    categories: Record<string, number>;
  }[];
}

export interface CareerProfile {
  id: string;
  title: string;
  description: string;
  characteristics: string[];
  careers: string[];
  color: string;
}

export interface QuizResult {
  profile: CareerProfile;
  scores: Record<string, number>;
}
